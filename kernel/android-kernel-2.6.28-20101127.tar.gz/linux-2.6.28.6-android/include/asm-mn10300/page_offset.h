/* MN10300 Kernel base address
 *
 * Copyright (C) 2007 Red Hat, Inc. All Rights Reserved.
 * Written by David Howells (dhowells@redhat.com)
 */
#ifndef _ASM_PAGE_OFFSET_H
#define _ASM_PAGE_OFFSET_H

#define PAGE_OFFSET_RAW CONFIG_KERNEL_RAM_BASE_ADDRESS

#endif

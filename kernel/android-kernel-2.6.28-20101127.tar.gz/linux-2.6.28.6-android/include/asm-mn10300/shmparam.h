#ifndef _ASM_SHMPARAM_H
#define _ASM_SHMPARAM_H

#define	SHMLBA PAGE_SIZE		 /* attach addr a multiple of this */

#endif /* _ASM_SHMPARAM_H */
